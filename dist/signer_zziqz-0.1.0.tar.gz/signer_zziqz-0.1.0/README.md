# signer-zziqz
### to install:
```bash
pip3 install signer-zziqz
```
